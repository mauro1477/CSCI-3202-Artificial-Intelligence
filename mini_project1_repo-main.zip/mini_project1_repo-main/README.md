# CSCI 3202: Mini Project 1 

Please use this repository to check out the most current version of the files for mini project 1. When checking out please be careful not to overwrite your work. Also, do not try to commit to this repository. You will be uploading your code and report on canvas.

See the jupyter notebook for further instructions.
